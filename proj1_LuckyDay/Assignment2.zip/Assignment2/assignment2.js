//date - specifically the time
var time=new Date();
var hour=time.getHours();
var min=time.getMinutes();
var dateTime=document.getElementById('time');
if(min<10){
  min='0'+min;
}
if(hour>=0 && hour<=5){
  if(hour==0){
    dateTime.innerHTML="The time is currently 12:"+min;
  }
  else{
    dateTime.innerHTML="The time is currently "+hour+":"+min+"am - Good Night!";
  }
}
else if (hour>=6 && hour<=11) {
  dateTime.innerHTML="The time is currently "+hour+":"+min+"am - Good Morning!";
}
else if (hour>=12 && hour<=17) {
  if(hour==12){
    dateTime.innerHTML="The time is currently "+hour+":"+min+"pm - Good Afternoon!";
  }
  else{
    hour=hour-12;
    dateTime.innerHTML="The time is currently "+hour+":"+min+"pm - Good Afternoon!";
  }
}
else {
  hour=hour-12;
  dateTime.innerHTML="The time is currently "+hour+":"+min+"pm - Good Evening!";
}

//random color
var colorNum = parseInt( Math.random() * 6 );
var lucky=document.getElementById('luckyColor');
var color=['red', 'green', 'blue', 'orange', 'pink', 'yellow'];
lucky.style['background-color'] = color[colorNum];
lucky.innerHTML = "Today's lucky color is "+color[colorNum];
lucky.style['border-radius']='25px';

//random ball
var pic1 = document.getElementById('first');
var pic2 = document.getElementById('second');
var pic3 = document.getElementById('third');
var balls = ['ball_1.png', 'ball_2.png', 'ball_3.png', 'ball_4.png', 'ball_5.png', 'ball_6.png', 'ball_7.png', 'ball_8.png', 'ball_9.png'];
//first ball
var num1 = parseInt( Math.random() * 9 );
pic1.setAttribute('src', balls[num1]);
balls.splice(num1, 1);
//second ball
var num2 = parseInt( Math.random() * 8 );
pic2.setAttribute('src', balls[num2]);
balls.splice(num2, 1);
//third ball
var num3 = parseInt( Math.random() * 7 );
pic3.setAttribute('src', balls[num3]);
