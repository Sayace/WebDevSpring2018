//Dealing with tabs
var tabClass = document.querySelectorAll('.tab');
var first = document.getElementById('first');
var second = document.getElementById('second');
var shop = document.getElementById('shop');
var checkout = document.getElementById('checkout');
for (var i = 0; i < 2; i++) {
  tabClass[i].onclick = function(event) {
    var current= event.currentTarget;
    document.querySelector('.active').classList.remove('active');
    current.classList.add('active');
    //console.log(event.currentTarget);
    if(event.currentTarget===first){
      first.classList.remove('hidden');
      shop.classList.remove('hidden');
      checkout.classList.add('hidden');
    }
    else{
      second.classList.remove('hidden');
      checkout.classList.remove('hidden');
      shop.classList.add('hidden');
    }
  }
}

//Dealing with forms
var poroHowMany = document.getElementById('howMany1');
var pachimariHowMany = document.getElementById('howMany2');
var junimoHowMany = document.getElementById('howMany3');
var poroQuantity=0;
var pachimariQuantity=0;
var junimoQuantity=0;
var question = document.querySelectorAll('.question');
//checkout variables
var totalValue = document.getElementById('total');
var noItems = document.getElementById('noItems');
var items = document.getElementById('items');
var poroList = document.createElement("li");
var pachimariList = document.createElement("li");
var junimoList = document.createElement("li");
var total = 0;
var inputInt = 0;

document.getElementById('submit1').onclick = function(event) {
  //Forms on the buy side
  event.preventDefault();
  var input = document.getElementById("poro").value;
  if(input==="question"){
    poroHowMany.innerHTML = "Please select a number!";
  }
  else{
    inputInt = parseInt(input);
    poroQuantity += parseInt(input);
    poroHowMany.innerHTML = poroQuantity + " poro added to cart in total";
    //console.log(poroQuantity);
  }
  //forms on the checkout side
  if(poroQuantity>0){
    noItems.classList.add('hidden');
    items.classList.remove('hidden');
    //console.log(noItems.classList);
    //console.log(items.classList);
    poroList.innerHTML = "Poro: " + poroQuantity + " @10 per poro";
    items.appendChild(poroList);
  }
  total += inputInt * 10;
  totalValue.innerHTML = "Total cost: $" + total;
  question[0].selected = true;
}
document.getElementById('submit2').onclick = function(event) {
  event.preventDefault();
  var input = document.getElementById("pachimari").value;
  if(input==="question"){
    pachimariHowMany.innerHTML = "Please select a number!";
  }
  else{
    inputInt = parseInt(input);
    pachimariQuantity += parseInt(input);
    pachimariHowMany.innerHTML = pachimariQuantity + " pachimari added to cart in total";
  }
  //forms on the checkout side
  if(pachimariQuantity>0){
    noItems.classList.add('hidden');
    items.classList.remove('hidden');
    //console.log(noItems.classList);
    //console.log(items.classList);
    pachimariList.innerHTML = "Pachimari: " + pachimariQuantity + " @15 per pachimari";
    items.appendChild(pachimariList);
  }
  total += inputInt * 15;
  totalValue.innerHTML = "Total cost: $" + total;
  question[1].selected = true;
}

document.getElementById('submit3').onclick = function(event) {
  event.preventDefault();
  var input = document.getElementById("junimo").value;
  if(input==="question"){
    junimoHowMany.innerHTML = "Please select a number!";
  }
  else{
    inputInt = parseInt(input);
    junimoQuantity += parseInt(input);
    junimoHowMany.innerHTML = junimoQuantity + " junimo added to cart in total";
  }
  //forms on the checkout side
  if(junimoQuantity>0){
    noItems.classList.add('hidden');
    items.classList.remove('hidden');
    //console.log(noItems.classList);
    //console.log(items.classList);
    junimoList.innerHTML = "Junimo: " + junimoQuantity + " @20 per junimo";
    items.appendChild(junimoList);
  }
  total += inputInt * 20;
  totalValue.innerHTML = "Total cost: $" + total;
  question[2].selected = true;
}
