<?php

  setcookie('gravityfalls', '', time()-3600);
  header('Location: index.php');

?>
