<!DOCTYPE html>
<html>
  <head>
    <title>Quizzing System</title>

    <style>
      body{
        text-align: center;
        font-family: verdana;
        background-color: MediumAquaMarine;
      }
      a{
        text-decoration: none;
      }
      h1{
        color: papayawhip;
      }
      #main{
        background-color: papayawhip;
        border-radius: 30px;
        border: 5px solid black;
        width: 50%;
        height: 300px;
        margin: auto;
        padding: 5%;
      }
      img{
        border: 5px solid black;
        background-color: MediumAquaMarine;
      }
    </style>
  </head>
  <body>
    <h1>Which Gravity Falls Character Are You?</h1>
    <div id="main">
    <?php

      if ($_COOKIE['gravityfalls']) {

        print '<img src="images/' . $_COOKIE['gravityfalls'] . '.gif"></br>';
        print '</br><a href="tryagain.php">Try again</a></br>';
      }

      else {

        print '
        <form method="post" action="processdata.php">
          <p>What is your favorite color?</p>
          <select name="color">
            <option value="">Select a color</option>
            <option value="pink">Pink</option>
            <option value="green">Green</option>
            <option value="blue">Blue</option>
            <option value="yellow">Yellow</option>
          </select>
          </br>
          <p>Which symbol do you feel represents you?</p>
          <select name="symbol">
            <option value="">Select a symbol</option>
            <option value="tree">A pine tree</option>
            <option value="star">A shooting star</option>
            <option value="llama">A llama</option>
            <option value="ice">A bag of ice</option>
          </select>
          </br>
          <p>What is your favorite season?</p>
          <select name="season">
            <option value="">Select a season</option>
            <option value="summer">Summer</option>
            <option value="winter">Winter</option>
            <option value="spring">Spring</option>
            <option value="fall">Fall</option>
          </select>
          </br>
          </br>
          <input type="submit">
          </br>
          </br>
        </form>';

      }

    ?>

    <?php
      // look for incomplete error flag
      if ($_GET['error'] === 'incomplete') {
        print '<p>Incomplete form!</p>';
      }
    ?>

  </br>
    <a href="results.php">See Aggregrate Results</a>
    </div>
  </body>
</html>
