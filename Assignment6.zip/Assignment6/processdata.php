<?php

  // access the form
  $color = $_POST['color'];
  $symbol = $_POST['symbol'];
  $season = $_POST['season'];

  print $season . $color . $symbol;

  // make sure they filled the form out
  if ($color === "" || $symbol === "" || $season === "") {
    // incomplete form values
    header("Location: index.php?error=incomplete");
  }

  // if they filled it out, figure out which pokemon they are
  else {

    $dipper = 0;
    $mabel = 0;
    $pacifica = 0;
    $wendy = 0;

    //count results
    //color
    if ($color === "pink") {
      $mabel++;
    }
    else if ($color === "green") {
      $wendy++;
    }
    else if ($color === "blue") {
      $dipper++;
    }
    else {
      $pacifica++;
    }

    //symbol
    if ($symbol === "tree") {
      $dipper++;
    }
    else if ($symbol === "ice") {
      $wendy++;
    }
    else if ($symbol === "star") {
      $mabel++;
    }
    else {
      $pacifica++;
    }

    //seasons
    if ($season === "summer") {
      $dipper++;
    }
    else if ($season === "fall") {
      $wendy++;
    }
    else if ($season === "spring") {
      $mabel++;
    }
    else {
      $pacifica++;
    }

    //determine
    //if dipper is the highest then dipper is the result
    if (($dipper > $mabel) && ($dipper > $wendy) && ($dipper > $pacifica)) {
      $gravityfalls = "dipper";
    }
    //if mabel is the highest mabel is the result
    else if (($mabel > $dipper) && ($mabel > $wendy) && ($mabel > $pacifica)) {
      $gravityfalls = "mabel";
    }
    //if wendy is the highest wendy is the result
    else if (($wendy > $dipper) && ($wendy > $mabel) && ($wendy > $pacifica)) {
      $gravityfalls = "wendy";
    }
    //if there is a tie or the results point to pacifica the result is pacifica
    else {
      $gravityfalls = "pacifica";
    }

    $file = 'results.txt';
    file_put_contents($file, $gravityfalls."\n", FILE_APPEND);

    setcookie('gravityfalls', $gravityfalls);

    // redirect them back to the main page
    header('Location: index.php');
  }

?>
