<style>
  body{
    text-align: center;
    font-family: verdana;
    background-color: MediumAquaMarine;
  }
  div {
    height: 50px;
    border: 1px solid MediumAquaMarine;
    margin: 5px;
    text-align: left;
    color: MediumAquaMarine;
    width: 100%;
  }
  h1{
    color: papayawhip;
  }
  #main{
    background-color: papayawhip;
    border-radius: 30px;
    border: 5px solid black;
    width: 50%;
    height: 300px;
    margin: auto;
    padding: 5%;
  }
  #dipper{
    background-color: blue;
  }
  #mabel{
    background-color: pink;
  }
  #wendy{
    background-color: green;
  }
  #pacifica{
    background-color: yellow;
  }
  a{
    text-decoration: none;
    text-align: center;
    margin-left: 270px;
    margin-top: 100px;
  }
</style>

<?php

  // open the file
  $file = 'results.txt';
  $data = file_get_contents($file);

  // count the results
  $lines = explode("\n", $data);
  $dipper = 0;
  $mabel = 0;
  $wendy = 0;
  $pacifica = 0;

  for ($i = 0; $i < sizeof($lines); $i++) {
    if ($lines[$i] === 'dipper') {
      $dipper++;
    }
    else if ($lines[$i] === 'mabel') {
      $mabel++;
    }
    else if ($lines[$i] === 'wendy') {
      $wendy++;
    }
    else if ($lines[$i] === 'pacifica'){
      $pacifica++;
    }
  }

  $dipperwidthprint = 0;
  $mabelwidthprint = 0;
  $wendywidthprint = 0;
  $pacificawidthprint = 0;
  if ($_COOKIE['gravityfalls']) {
    $dipperwidth = ($dipper / (sizeof($lines)-1)) * 100;
    $mabelwidth = ($mabel / (sizeof($lines)-1)) * 100;
    $wendywidth = ($wendy / (sizeof($lines)-1)) * 100;
    $pacificawidth = ($pacifica / (sizeof($lines)-1)) * 100;
    $dipperwidthprint = $dipperwidth;
    $mabelwidthprint = $mabelwidth;
    $wendywidthprint = $wendywidth;
    $pacificawidthprint = $pacificawidth;
  }

?>

<body>
  <h1>Results</h1>
  <div id="main">
    <div id="dipper" style="width: <?php print $dipperwidth; ?>%;">Dipper <?php print $dipperwidthprint; ?>%</div>
    <div id="mabel" style="width: <?php print $mabelwidth; ?>%;">Mabel <?php print $mabelwidthprint; ?>%</div>
    <div id="wendy" style="width: <?php print $wendywidth; ?>%;">Wendy <?php print $wendywidthprint; ?>%</div>
    <div id="pacifica" style="width: <?php print $pacificawidth; ?>%;">Pacifica <?php print $pacificawidthprint; ?>%</div>
    <a href="index.php">Back to Quiz</a>
  </div>
</body>
